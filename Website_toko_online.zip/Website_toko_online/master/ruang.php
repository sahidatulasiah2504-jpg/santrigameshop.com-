<?php
session_start();
require 'config/koneksi.php';
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
// TAMBAH DATA
if (isset($_POST['tambah'])) {
  $id = $_POST['id_ruang'];
  $nama = $_POST['nama_ruang'];
  $cabang = $_POST['id_cabang'];
  $conn->query("INSERT INTO ruang VALUES ('$id','$nama','$cabang')");
  header("Location: ruang.php");
}

// HAPUS DATA
if (isset($_GET['hapus'])) {
  $id = $_GET['hapus'];
  $conn->query("DELETE FROM ruang WHERE id_ruang='$id'");
  header("Location: ruang.php");
}

// EDIT DATA
if (isset($_POST['edit'])) {
  $id = $_POST['id_ruang'];
  $nama = $_POST['nama_ruang'];
  $cabang = $_POST['id_cabang'];
  $conn->query("UPDATE ruang SET nama_ruang='$nama', id_cabang='$cabang' WHERE id_ruang='$id'");
  header("Location: ruang.php");
}

// DATA EDIT
$editData = null;
if (isset($_GET['edit'])) {
  $id = $_GET['edit'];
  $editData = $conn->query("SELECT * FROM ruang WHERE id_ruang='$id'")->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Master Data Ruang</title>
<style>
body{font-family:Arial;background:#f5f5f5}
.container{max-width:900px;margin:20px auto}
.card{background:#fff;padding:20px;border-radius:12px}
table{width:100%;border-collapse:collapse;margin-top:15px}
th,td{border:1px solid #ccc;padding:10px;text-align:center}
th{background:#64b5f6}
.btn{padding:6px 12px;border:none;border-radius:6px;color:#fff;cursor:pointer}
.add{background:#1e88e5}
.edit{background:#fbc02d;color:#000}
.delete{background:#e53935}
</style>
</head>

<body>
<div class="container">
<div class="card">
<h2>Master Data Ruang</h2>

<form method="post">
  <input type="text" name="id_ruang" placeholder="ID Ruang" required
    value="<?= $editData['id_ruang'] ?? '' ?>" <?= $editData ? 'readonly' : '' ?>>
  <input type="text" name="nama_ruang" placeholder="Nama Ruang" required
    value="<?= $editData['nama_ruang'] ?? '' ?>">
  <input type="text" name="id_cabang" placeholder="ID Cabang" required
    value="<?= $editData['id_cabang'] ?? '' ?>">

  <?php if ($editData): ?>
    <button class="btn edit" name="edit">Update</button>
  <?php else: ?>
    <button class="btn add" name="tambah">Tambah</button>
  <?php endif; ?>
</form>

<table>
<tr>
  <th>No</th>
  <th>ID Ruang</th>
  <th>Nama Ruang</th>
  <th>ID Cabang</th>
  <th>Aksi</th>
</tr>

<?php
$no = 1;
$data = $conn->query("SELECT * FROM ruang");
while ($r = $data->fetch_assoc()):
?>
<tr>
  <td><?= $no++ ?></td>
  <td><?= $r['id_ruang'] ?></td>
  <td><?= $r['nama_ruang'] ?></td>
  <td><?= $r['id_cabang'] ?></td>
  <td>
    <a class="btn edit" href="?edit=<?= $r['id_ruang'] ?>">Edit</a>
    <a class="btn delete" href="?hapus=<?= $r['id_ruang'] ?>" onclick="return confirm('Hapus data?')">Hapus</a>
  </td>
</tr>
<?php endwhile; ?>

</table>
</div>
</div>
</body>
</html>