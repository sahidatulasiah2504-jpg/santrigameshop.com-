<?php
session_start();
require 'config/koneksi.php';
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// ===== PROSES CRUD =====
if(isset($_POST['simpan'])){
  mysqli_query($koneksi,"INSERT INTO pelanggan VALUES(
    '$_POST[id_pelanggan]',
    '$_POST[nama]',
    '$_POST[kota]',
    '$_POST[email]'
  )");
  header("location:pelanggan.php");
}

if(isset($_POST['update'])){
  mysqli_query($koneksi,"UPDATE pelanggan SET
    nama='$_POST[nama]',
    kota='$_POST[kota]',
    email='$_POST[email]'
    WHERE id_pelanggan='$_POST[id_pelanggan]'
  ");
  header("location:pelanggan.php");
}

if(isset($_GET['hapus'])){
  mysqli_query($koneksi,"DELETE FROM pelanggan WHERE id_pelanggan='$_GET[hapus]'");
  header("location:pelanggan.php");
}

// ===== DATA EDIT =====
$edit = null;
if(isset($_GET['edit'])){
  $q = mysqli_query($koneksi,"SELECT * FROM pelanggan WHERE id_pelanggan='$_GET[edit]'");
  $edit = mysqli_fetch_assoc($q);
}

// ===== AMBIL DATA =====
$data = mysqli_query($koneksi,"SELECT * FROM pelanggan");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Master Data Pelanggan</title>
<style>
body{font-family:Arial;background:#f5f5f5}
.container{max-width:1000px;margin:20px auto}
form{background:#fff;padding:15px;border-radius:10px;margin-bottom:20px}
input{padding:8px;margin:5px}
.btn{padding:6px 12px;border:none;border-radius:6px;color:#fff;cursor:pointer}
.add{background:#1e88e5}
.edit{background:#fbc02d;color:#000}
.delete{background:#e53935}
table{width:100%;border-collapse:collapse;background:#fff}
th,td{border:1px solid #ddd;padding:10px;text-align:center}
th{background:#64b5f6}
</style>
</head>

<body>
<div class="container">

<h2 align="center">Master Data Pelanggan</h2>

<!-- ===== FORM ===== -->
<form method="post">
  <input type="text" name="id_pelanggan" placeholder="ID Pelanggan"
    value="<?= $edit['id_pelanggan'] ?? '' ?>"
    <?= isset($edit)?'readonly':'' ?> required>
  <input type="text" name="nama" placeholder="Nama Pelanggan"
    value="<?= $edit['nama'] ?? '' ?>" required>
  <input type="text" name="kota" placeholder="Kota"
    value="<?= $edit['kota'] ?? '' ?>" required>
  <input type="email" name="email" placeholder="Email"
    value="<?= $edit['email'] ?? '' ?>" required>

  <?php if(isset($edit)){ ?>
    <button class="btn edit" name="update">Update</button>
  <?php } else { ?>
    <button class="btn add" name="simpan">Simpan</button>
  <?php } ?>
</form>

<!-- ===== TABEL ===== -->
<table>
<tr>
  <th>No</th>
  <th>ID Pelanggan</th>
  <th>Nama</th>
  <th>Kota</th>
  <th>Email</th>
  <th>Aksi</th>
</tr>

<?php $no=1; while($row=mysqli_fetch_assoc($data)){ ?>
<tr>
  <td><?= $no++ ?></td>
  <td><?= $row['id_pelanggan'] ?></td>
  <td><?= $row['nama'] ?></td>
  <td><?= $row['kota'] ?></td>
  <td><?= $row['email'] ?></td>
  <td>
    <a href="?edit=<?= $row['id_pelanggan'] ?>" class="btn edit">Edit</a>
    <a href="?hapus=<?= $row['id_pelanggan'] ?>"
       onclick="return confirm('Hapus data?')"
       class="btn delete">Hapus</a>
  </td>
</tr>
<?php } ?>
</table>

</div>
</body>
</html>