<?php
session_start();
require 'config/koneksi.php';
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// ====== PROSES CRUD ======
if(isset($_POST['simpan'])){
  mysqli_query($koneksi,"INSERT INTO kurir VALUES(
    '$_POST[id_kurir]',
    '$_POST[nama_kurir]',
    '$_POST[layanan]'
  )");
  header("location:kurir.php");
}

if(isset($_POST['update'])){
  mysqli_query($koneksi,"UPDATE kurir SET
    nama_kurir='$_POST[nama_kurir]',
    layanan='$_POST[layanan]'
    WHERE id_kurir='$_POST[id_kurir]'
  ");
  header("location:kurir.php");
}

if(isset($_GET['hapus'])){
  mysqli_query($koneksi,"DELETE FROM kurir WHERE id_kurir='$_GET[hapus]'");
  header("location:kurir.php");
}

// ====== DATA EDIT ======
$edit = null;
if(isset($_GET['edit'])){
  $q = mysqli_query($koneksi,"SELECT * FROM kurir WHERE id_kurir='$_GET[edit]'");
  $edit = mysqli_fetch_assoc($q);
}

// ====== AMBIL DATA ======
$data = mysqli_query($koneksi,"SELECT * FROM kurir");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Master Data Kurir</title>
<body>
<div class="container">

<h2 align="center">Master Data Kurir</h2>

<!-- ===== FORM ===== -->
<form method="post">
  <input type="text" name="id_kurir" placeholder="ID Kurir"
    value="<?= $edit['id_kurir'] ?? '' ?>"
    <?= isset($edit)?'readonly':'' ?> required>
  <input type="text" name="nama_kurir" placeholder="Nama Kurir"
    value="<?= $edit['nama_kurir'] ?? '' ?>" required>
  <input type="text" name="layanan" placeholder="Layanan"
    value="<?= $edit['layanan'] ?? '' ?>" required>

  <?php if(isset($edit)){ ?>
    <button class="btn edit" name="update">Update</button>
  <?php } else { ?>
    <button class="btn add" name="simpan">Simpan</button>
  <?php } ?>
</form>

<!-- ===== TABEL ===== -->
<table>
<tr>
  <th>No</th>
  <th>ID Kurir</th>
  <th>Nama Kurir</th>
  <th>Layanan</th>
  <th>Aksi</th>
</tr>

<?php $no=1; while($row=mysqli_fetch_assoc($data)){ ?>
<tr>
  <td><?= $no++ ?></td>
  <td><?= $row['id_kurir'] ?></td>
  <td><?= $row['nama_kurir'] ?></td>
  <td><?= $row['layanan'] ?></td>
  <td>
    <a href="?edit=<?= $row['id_kurir'] ?>" class="btn edit">Edit</a>
    <a href="?hapus=<?= $row['id_kurir'] ?>"
       onclick="return confirm('Hapus data?')"
       class="btn delete">Hapus</a>
  </td>
</tr>
<?php } ?>
</table>

</div>
</body>
</html>