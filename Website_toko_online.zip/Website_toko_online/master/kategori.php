<?php
session_start();
require 'config/koneksi.php';
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Master Kategori - Sistem Toko Online</title>

<div class="container">
  <div class="header">
    <h1>Master Kategori</h1>
    <div class="actions">
      <button class="btn add" onclick="tambahKategori()">Tambah Kategori</button>
      <button class="btn back" onclick="window.history.back()">Kembali</button>
    </div>
  </div>

  <table class="table">
    <thead>
      <tr>
        <th>No</th>
        <th>id Kategori</th>
        <th>Nama Kategori</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $no=1;
    $data = mysqli_query($koneksi,"SELECT * FROM kategori");
    while($row = mysqli_fetch_assoc($data)){
    ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['id_kategori'] ?></td>
        <td><?= $row['nama_kategori'] ?></td>
        <td>
          <div class="flex-btn">
            <button class="btn edit"
              onclick="editKategori(
                '<?= $row['id_kategori'] ?>',
                '<?= $row['nama_kategori'] ?>'
              )">Edit</button>
            <button class="btn delete"
              onclick="hapusKategori('<?= $row['id_kategori'] ?>')">Hapus</button>
          </div>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
</div>

<script>
// TAMBAH
function tambahKategori(){
  const id = prompt("Masukkan ID Kategori:");
  if(!id) return;
  const nama = prompt("Masukkan Nama Kategori:");
  if(!nama) return;

  location.href = `?aksi=tambah&id=${id}&nama=${nama}`;
}

// EDIT
function editKategori(id,nama){
  const namaBaru = prompt("Edit Nama Kategori:",nama);
  if(!namaBaru) return;

  location.href = `?aksi=edit&id=${id}&nama=${namaBaru}`;
}

// HAPUS
function hapusKategori(id){
  if(confirm("Yakin ingin menghapus kategori ini?")){
    location.href = `?aksi=hapus&id=${id}`;
  }
}
</script>

<?php
// ===== PROSES CRUD =====
if(isset($_GET['aksi'])){
  if($_GET['aksi']=="tambah"){
    mysqli_query($koneksi,"INSERT INTO kategori VALUES(
      '$_GET[id]',
      '$_GET[nama]'
    )");
    echo "<script>location.href='kategori.php'</script>";
  }

  if($_GET['aksi']=="edit"){
    mysqli_query($koneksi,"UPDATE kategori SET
      nama_kategori='$_GET[nama]'
      WHERE id_kategori='$_GET[id]'
    ");
    echo "<script>location.href='kategori.php'</script>";
  }

  if($_GET['aksi']=="hapus"){
    mysqli_query($koneksi,"DELETE FROM kategori WHERE id_kategori='$_GET[id]'");
    echo "<script>location.href='kategori.php'</script>";
  }
}
?>
</body>
</html>