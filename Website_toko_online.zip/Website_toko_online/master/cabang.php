<?php
session_start();
require 'config/koneksi.php';

if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit;
}

// Ambil data
$data = $koneksi->query("SELECT * FROM kategori");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Master Data Kategori</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h3>Master Data Kategori</h3>
    <a href="index.php" class="btn btn-secondary mb-3">← Kembali</a>

    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Nama Kategori</th>
        </tr>
        <?php while($row = $data->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id_kategori'] ?></td>
            <td><?= $row['nama_kategori'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

</body>
</html>