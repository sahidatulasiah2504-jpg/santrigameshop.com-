<?php
session_start();
require 'config/koneksi.php';
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_cabang = $_POST['id_cabang'];
    $nama_cabang = $_POST['nama_cabang'];
    $kota = $_POST['kota'];

    $stmt = $conn->prepare("INSERT INTO cabang (, id_cabang, nama_cabang, kota,) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssii", $judul, $pengarang, $penerbit, $tahun_terbit, $stok);
    $stmt->execute();

    header("Location: buku.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah cabang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<div class="container mt-4">
    <h3>Tambah cabang</h3>
    <form method="POST">
        <div class="mb-3">
            <label>id_cabang</label>
            <input type="text" name="id_cabang" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>nama_cabang</label>
            <input type="text" name="nama_cabang" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>kota</label>
            <input type="text" name="kota" class="form-control">
        
        </div>
        <button class="btn btn-primary" type="submit">Simpan</button>
        <a href="buku.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>