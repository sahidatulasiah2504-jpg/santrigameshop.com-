<?php
session_start();
require 'config/koneksi.php';
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// ===== PROSES CRUD =====
if(isset($_POST['simpan'])){
  mysqli_query($koneksi,"INSERT INTO produk VALUES(
    '$_POST[id_produk]',
    '$_POST[nama]',
    '$_POST[harga]',
    '$_POST[stok]',
    '$_POST[kategori]',
    '$_POST[supplier]'
  )");
  header("location:produk.php");
}

if(isset($_POST['update'])){
  mysqli_query($koneksi,"UPDATE produk SET
    nama_produk='$_POST[nama]',
    harga='$_POST[harga]',
    stok='$_POST[stok]',
    id_kategori='$_POST[kategori]',
    id_supplier='$_POST[supplier]'
    WHERE id_produk='$_POST[id_produk]'
  ");
  header("location:produk.php");
}

if(isset($_GET['hapus'])){
  mysqli_query($koneksi,"DELETE FROM produk WHERE id_produk='$_GET[hapus]'");
  header("location:produk.php");
}

// ===== DATA EDIT =====
$edit = null;
if(isset($_GET['edit'])){
  $q = mysqli_query($koneksi,"SELECT * FROM produk WHERE id_produk='$_GET[edit]'");
  $edit = mysqli_fetch_assoc($q);
}

// ===== DATA TABEL =====
$data = mysqli_query($koneksi,"SELECT * FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Master Data Produk</title>
<style>
body{font-family:Arial;background:#f5f5f5}
.container{max-width:1200px;margin:20px auto}
form{background:#fff;padding:15px;border-radius:10px;margin-bottom:20px}
input{padding:8px;margin:4px}
.btn{padding:6px 12px;border:none;border-radius:6px;color:#fff;cursor:pointer}
.add{background:#1e88e5}
.edit{background:#fbc02d;color:#000}
.delete{background:#e53935}
table{width:100%;border-collapse:collapse;background:#fff}
th,td{border:1px solid #ddd;padding:10px;text-align:center}
th{background:#64b5f6}
</style>
</head>

<body>
<div class="container">

<h2 align="center">Master Data Produk</h2>

<!-- ===== FORM TAMBAH / EDIT ===== -->
<form method="post">
  <input type="text" name="id_produk" placeholder="ID Produk"
    value="<?= $edit['id_produk'] ?? '' ?>"
    <?= isset($edit)?'readonly':'' ?> required>

  <input type="text" name="nama" placeholder="Nama Produk"
    value="<?= $edit['nama_produk'] ?? '' ?>" required>

  <input type="number" name="harga" placeholder="Harga"
    value="<?= $edit['harga'] ?? '' ?>" required>

  <input type="number" name="stok" placeholder="Stok"
    value="<?= $edit['stok'] ?? '' ?>" required>

  <input type="text" name="kategori" placeholder="Kategori ID"
    value="<?= $edit['id_kategori'] ?? '' ?>" required>

  <input type="text" name="supplier" placeholder="Supplier ID"
    value="<?= $edit['id_supplier'] ?? '' ?>" required>

  <?php if(isset($edit)){ ?>
    <button class="btn edit" name="update">Update</button>
  <?php } else { ?>
    <button class="btn add" name="simpan">Simpan</button>
  <?php } ?>
</form>

<!-- ===== TABEL DATA ===== -->
<table>
<tr>
  <th>No</th>
  <th>ID Produk</th>
  <th>Nama Produk</th>
  <th>Harga</th>
  <th>Stok</th>
  <th>Kategori ID</th>
  <th>Supplier ID</th>
  <th>Aksi</th>
</tr>

<?php $no=1; while($row=mysqli_fetch_assoc($data)){ ?>
<tr>
  <td><?= $no++ ?></td>
  <td><?= $row['id_produk'] ?></td>
  <td><?= $row['nama_produk'] ?></td>
  <td><?= $row['harga'] ?></td>
  <td><?= $row['stok'] ?></td>
  <td><?= $row['id_kategori'] ?></td>
  <td><?= $row['id_supplier'] ?></td>
  <td>
    <a href="?edit=<?= $row['id_produk'] ?>" class="btn edit">Edit</a>
    <a href="?hapus=<?= $row['id_produk'] ?>"
       onclick="return confirm('Hapus produk?')"
       class="btn delete">Hapus</a>
  </td>
</tr>
<?php } ?>
</table>

</div>
</body>
</html>