
<?php
session_start();
require 'config/koneksi.php';
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// TAMBAH DATA
if (isset($_POST['tambah'])) {
  $id = $_POST['id_supplier'];
  $nama = $_POST['nama_supplier'];
  $kontak = $_POST['kontak'];
  $conn->query("INSERT INTO supplier VALUES ('$id','$nama','$kontak')");
  header("Location: supplier.php");
}

// HAPUS DATA
if (isset($_GET['hapus'])) {
  $id = $_GET['hapus'];
  $conn->query("DELETE FROM supplier WHERE id_supplier='$id'");
  header("Location: supplier.php");
}

// EDIT DATA
if (isset($_POST['edit'])) {
  $id = $_POST['id_supplier'];
  $nama = $_POST['nama_supplier'];
  $kontak = $_POST['kontak'];
  $conn->query("UPDATE supplier SET nama_supplier='$nama', kontak='$kontak' WHERE id_supplier='$id'");
  header("Location: supplier.php");
}

// DATA EDIT
$editData = null;
if (isset($_GET['edit'])) {
  $id = $_GET['edit'];
  $editData = $conn->query("SELECT * FROM supplier WHERE id_supplier='$id'")->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Master Data Supplier</title>
<style>
body{font-family:Arial;background:#f5f5f5}
.container{max-width:900px;margin:20px auto}
.card{background:#fff;padding:20px;border-radius:12px}
table{width:100%;border-collapse:collapse;margin-top:15px}
th,td{border:1px solid #ccc;padding:10px;text-align:center}
th{background:#64b5f6}
.btn{padding:6px 12px;border:none;border-radius:6px;color:#fff;cursor:pointer;text-decoration:none}
.add{background:#1e88e5}
.edit{background:#fbc02d;color:#000}
.delete{background:#e53935}
</style>
</head>

<body>
<div class="container">
<div class="card">
<h2>Master Data Supplier</h2>

<form method="post">
  <input type="text" name="id_supplier" placeholder="ID Supplier" required
    value="<?= $editData['id_supplier'] ?? '' ?>" <?= $editData ? 'readonly' : '' ?>>
  <input type="text" name="nama_supplier" placeholder="Nama Supplier" required
    value="<?= $editData['nama_supplier'] ?? '' ?>">
  <input type="text" name="kontak" placeholder="Kontak" required
    value="<?= $editData['kontak'] ?? '' ?>">

  <?php if ($editData): ?>
    <button class="btn edit" name="edit">Update</button>
  <?php else: ?>
    <button class="btn add" name="tambah">Tambah</button>
  <?php endif; ?>
</form>

<table>
<tr>
  <th>No</th>
  <th>ID Supplier</th>
  <th>Nama Supplier</th>
  <th>Kontak</th>
  <th>Aksi</th>
</tr>

<?php
$no = 1;
$data = $conn->query("SELECT * FROM supplier");
while ($s = $data->fetch_assoc()):
?>
<tr>
  <td><?= $no++ ?></td>
  <td><?= $s['id_supplier'] ?></td>
  <td><?= $s['nama_supplier'] ?></td>
  <td><?= $s['kontak'] ?></td>
  <td>
    <a class="btn edit" href="?edit=<?= $s['id_supplier'] ?>">Edit</a>
    <a class="btn delete" href="?hapus=<?= $s['id_supplier'] ?>" onclick="return confirm('Hapus data?')">Hapus</a>
  </td>
</tr>
<?php endwhile; ?>

</table>
</div>
</div>
</body>
</html>