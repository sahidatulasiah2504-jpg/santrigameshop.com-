<?php
session_start();
require 'config/koneksi.php'; // koneksi sudah jalan

// contoh hitung total
function total($conn, $table){
    $q = $conn->query("SELECT COUNT(*) as total FROM $table");
    return $q ? $q->fetch_assoc()['total'] : 0;
}

// ambil 5 pelanggan terbaru
$pelanggan = $conn->query("SELECT * FROM pelanggan ORDER BY id_pelanggan DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Sistem Data Toko Online</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body>

<div class="dashboard">

<!-- SIDEBAR -->
<aside class="sidebar">
  <div class="profile">
    <img src="assets/sahidatul mahasiswa.jpg">
    <h3>SA Online Shop</h3>
    <p>Sistem Data Toko Online</p>
  </div>

  <a href="index.php" class="active"><i class="fa-solid fa-house"></i> Dashboard</a>

  <div class="section">Master Data</div>
  <a href="kategori.php"><i class="fa-solid fa-tags"></i> Kategori</a>
  <a href="cabang.php"><i class="fa-solid fa-store"></i> Cabang</a>
  <a href="supplier.php"><i class="fa-solid fa-truck"></i> Supplier</a>
  <a href="ruang.php"><i class="fa-solid fa-warehouse"></i> Ruang</a>
  <a href="produk.php"><i class="fa-solid fa-box"></i> Produk</a>
  <a href="kurir.php"><i class="fa-solid fa-motorcycle"></i> Kurir</a>
  <a href="pelanggan.php"><i class="fa-solid fa-users"></i> Pelanggan</a>
  <a href="platform.php"><i class="fa-solid fa-globe"></i> Platform</a>

  <div class="section">Transaksi</div>
  <a href="penjualan.php"><i class="fa-solid fa-cash-register"></i> Penjualan</a>
  <a href="detail.php"><i class="fa-solid fa-receipt"></i> Detail</a>
  <a href="pembayaran.php"><i class="fa-solid fa-credit-card"></i> Pembayaran</a>
  <a href="pengiriman.php"><i class="fa-solid fa-truck-fast"></i> Pengiriman</a>
  <a href="laporan.php"><i class="fa-solid fa-file-lines"></i> Laporan</a>
</aside>

<h3>Menu Laporan</h3>
<ul>
  <li><a href="laporan/laporan_pengiriman.php">Laporan Pengiriman</a></li>
  <li><a href="laporan/laporan_pembayaran.php">Laporan Pembayaran</a></li>
</ul>

<!-- CONTENT -->
<main class="content">

<div class="cards">

  <div class="card">
    <i class="fa-solid fa-database"></i>
    <h3>Master Data</h3>
    <p>8 tabel<br>Total <?= 
        total($conn,'cabang') +
        total($conn,'kategori') +
        total($conn,'produk'); ?> data</p>
  </div>

  <div class="card">
    <i class="fa-solid fa-cart-shopping"></i>
    <h3>Transaksi</h3>
    <p>Total <?= total($conn,'penjualan'); ?> transaksi</p>
  </div>

  <div class="card">
    <i class="fa-solid fa-chart-line"></i>
    <h3>Laporan</h3>
    <p>Rekap Penjualan</p>
  </div>

  <div class="card">
    <i class="fa-solid fa-users"></i>
    <h3>Pelanggan</h3>
    <p>Total <?= total($conn,'pelanggan'); ?> orang</p>
  </div>

</div>

<!-- TABEL PELANGGAN -->
<div class="table-section">
<h2>5 Pelanggan Terbaru</h2>

<table>
<thead>
<tr>
<th>No</th>
<th>Nama</th>
<th>Email</th>
<th>No HP</th>
</tr>
</thead>
<tbody>

<?php $no=1; while($p = $pelanggan->fetch_assoc()): ?>
<tr>
<td><?= $no++ ?></td>
<td><?= $p['nama_pelanggan'] ?></td>
<td><?= $p['email'] ?></td>
<td><?= $p['no_hp'] ?></td>
</tr>
<?php endwhile; ?>

</tbody>
</table>
</div>

</main>
</div>

</body>
</html>