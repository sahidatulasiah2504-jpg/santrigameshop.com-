<?php
$host = "localhost";  // biasanya localhost
$user = "root";       // username MySQL
$pass = "";           // password MySQL (default XAMPP kosong)
$db   = "sistem_toko_online"; // nama database yang sudah diimport

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>