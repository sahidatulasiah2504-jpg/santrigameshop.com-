<?php
include "../config/koneksi.php";

$query = mysqli_query($conn, "
SELECT 
  pengiriman.id_pengiriman,
  pengiriman.tanggal,
  pelanggan.nama_pelanggan,
  kurir.nama_kurir,
  status_pengiriman.nama_status,
  pengiriman.total
FROM pengiriman
JOIN pelanggan 
  ON pengiriman.id_pelanggan = pelanggan.id_pelanggan
JOIN kurir 
  ON pengiriman.id_kurir = kurir.id_kurir
JOIN status_pengiriman 
  ON pengiriman.id_status = status_pengiriman.id_status
");
?>

<h3>Laporan Pengiriman</h3>

<table border="1" cellpadding="5">
<tr>
  <th>No</th>
  <th>Tanggal</th>
  <th>Pelanggan</th>
  <th>Kurir</th>
  <th>Status</th>
  <th>Total</th>
</tr>

<?php $no=1; while($data = mysqli_fetch_array($query)){ ?>
<tr>
  <td><?= $no++ ?></td>
  <td><?= $data['tanggal'] ?></td>
  <td><?= $data['nama_pelanggan'] ?></td>
  <td><?= $data['nama_kurir'] ?></td>
  <td><?= $data['nama_status'] ?></td>
  <td>Rp <?= number_format($data['total']) ?></td>
</tr>
<?php } ?>
</table>