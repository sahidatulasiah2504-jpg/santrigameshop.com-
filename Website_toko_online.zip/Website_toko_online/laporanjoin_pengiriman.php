<?php
include "../config/koneksi.php";

$query = mysqli_query($conn, "
SELECT 
  pembayaran.tanggal_bayar,
  pelanggan.nama_pelanggan,
  pembayaran.metode,
  pembayaran.jumlah
FROM pembayaran
JOIN pengiriman 
  ON pembayaran.id_pengiriman = pengiriman.id_pengiriman
JOIN pelanggan 
  ON pengiriman.id_pelanggan = pelanggan.id_pelanggan
");
?>

<h3>Laporan Pembayaran</h3>

<table border="1" cellpadding="5">
<tr>
  <th>No</th>
  <th>Tanggal Bayar</th>
  <th>Pelanggan</th>
  <th>Metode</th>
  <th>Jumlah</th>
</tr>

<?php $no=1; while($data = mysqli_fetch_array($query)){ ?>
<tr>
  <td><?= $no++ ?></td>
  <td><?= $data['tanggal_bayar'] ?></td>
  <td><?= $data['nama_pelanggan'] ?></td>
  <td><?= $data['metode'] ?></td>
  <td>Rp <?= number_format($data['jumlah']) ?></td>
</tr>
<?php } ?>
</table>